# A Little Universe for Apu

A six-page, responsive surprise website made with plain HTML, CSS and JavaScript.

## Preview on your computer
1. Extract this ZIP.
2. Open the `apu_little_universe` folder.
3. Double-click `index.html` to open it in a browser.

## Publish with GitHub Pages
1. Create/open your GitHub repository.
2. Upload `index.html` and the entire `assets` folder (keep the folder name `assets`).
3. Commit the changes.
4. In the repository, open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for the Pages link to appear.

The music is generated softly in the browser and starts only after the visitor clicks **Music off** / **Music on**. All five supplied photos are included in `assets`.
